/**
 * This program analyzes text files and finds the number of characters, words and palindromes in the file.
 * It also prints all the palindromes in the file.
 * 
 * @author      Sharvai Patil (sp4479@g.rit.edu)
 * 
 */

package Ethic.Coding.Test;

import java.io.File;
import java.io.IOException;
import java.lang.Exception;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;


public class FileAnalyzer {

	public static void main(String args[]){
		System.out.println("~~~~~~~~~~~~~~~~~~~~ WELCOME TO THE FileAnalyzer ~~~~~~~~~~~~~~~~~~~~");

		if(args.length!=1){
			System.out.println("Error! Input should be: gradlew run --args='\"path to file\"'");
		}
		else{
			FileAnalyzer ob = new FileAnalyzer();

			// checking if the entered file exists
			boolean doesFileExist = ob.checkFileExists(args[0]);

			if(doesFileExist){
				// since the file exists, we will now analze the file
				Hashtable<String, Object> result = ob.analyzeFile(args[0]);

				// printing the results after the analysis
				System.out.println("Number of characters = "+(int)result.get("charCounter")+".");
				System.out.println("Number of words = "+(int)result.get("wordCounter")+".");
				System.out.println("Number of words which are palindromes = "+(int)result.get("palindromeCounter")+".");
				
				if((int)result.get("palindromeCounter")>0){
					System.out.println("All palindromes: ");
					List allPalindromes = (List)result.get("allPalindromes");
					Set<String> allUniquePalindromes = new HashSet<>(); // stores all unique palindromes
					
					for(Object palindrome: allPalindromes){
						System.out.println(palindrome.toString());

						allUniquePalindromes.add(palindrome.toString());
					}

					System.out.println("\nNumber of unique palindromes = "+allUniquePalindromes.size()+".");
					System.out.println("All unique palindromes: ");
					for(String palindrome: allUniquePalindromes){
						System.out.println(palindrome);
					}
				}
			}
		}

		System.out.println("\nBye! Credits: Sharvai Patil (sp4479@g.rit.edu)");
	}

	/**
	* This method checks if the input file exists and is a text file
	*
	* @param	filename - (String) filename of the file to be analyzed (that is, the absolute path of the file)
	*
	* @return	(boolean) true if the file exists and is a text file; false otherwise
	*
	*/
	boolean checkFileExists(String filename){
		try{
			System.out.println("File to analyze -> "+filename);
			
			// making sure the given file is a text file
			if(!filename.endsWith(".txt")){
				System.out.println("The file "+filename+" is not a txt.");
				return false;
			}
			
			// checking if the given file exists
			File fileCheck = new File(filename);
			System.out.println(fileCheck.getAbsolutePath());
			if(fileCheck.exists()){
				return true;
			}
			else{
				System.out.println("The file "+filename+" does not exist.");
			}
		}
		catch(Exception e){
			System.out.println("There was an exception. Exception message: "+e);
		}
		return false;
	}

	/**
	* This method analyzes the file and finds the number of characters, words and palindromes in it
	*
	* @param	filename - (String) filename of the file to be analyzed
	*
	* @return	(Hashtable) Has the result in the form of key(String)-value(Object) pairs
	*
	*/
	Hashtable<String, Object> analyzeFile(String filename){
		Hashtable<String, Object> result = new Hashtable<>(); // stores the result 

		try{
			File inputFile = new File(filename);
			BufferedReader br = new BufferedReader(new FileReader(inputFile));

			List<String> allPalindromes = new ArrayList<>(); // stores all the palindromes found in the file
			
			String line = ""; // stores every line that is read from the file

			int wordCounter = 0; // counter for the number of words in the file
			int charCounter = 0; // counter for the number of characters in the file
			int palindromeCounter = 0; // counter for the number of palindromes in the file

			// getting lines from the file
			while((line = br.readLine())!=null){

				// building each word character by character using a StringBuilder object
				// reason for using a StringBuilder object is because append operations will have O(1) time complexity
				// making the code more efficient
				StringBuilder currentWord = new StringBuilder(); 

				charCounter += line.length();

				line+=" "; // adding a whitespace at the end so that the last word that occurs is also recognized
				
				// building each word character by character
				for(int i=0; i<line.length(); i++){					
					if(line.charAt(i)==' '){
						if(currentWord.length()>0){
							// occurance of a whitespace signifies that a new word has been found

							// removing special characters at the start and end of the current word
							// to make sure the word has letters or digits in it so that the code works even with 
							// grammatical errors in the text file
							while(currentWord.length()>0){
								boolean wasChanged = false; // this variable is an indicator to see if there was a change made to currentWord
								// true if change was made, false otherwise

								// checking if the first character is a special character (eg., "hi)
								// if yes, removing it
								if(!Character.isLetterOrDigit(currentWord.charAt(0))){
									currentWord.deleteCharAt(0);
									wasChanged = true;
								}

								if(currentWord.length()==0)
									break;

								// checking if the last character is a special character (eg., hey!)
								// if yes, removing it
								if(!Character.isLetterOrDigit(currentWord.charAt(currentWord.length()-1))){
									currentWord.deleteCharAt(currentWord.length()-1);
									wasChanged = true;
								}

								// checking if there were any changes
								// If there were no changes made to currentWord, we break the loop
								if(wasChanged==false)
									break;
							}

							// making sure the string is not empty
							if(currentWord.length()==0)
								continue;

							wordCounter+=1;

							// checking if the current word is a palindrome
							if(isPalindrome(currentWord)){
								allPalindromes.add(currentWord.toString());
								palindromeCounter+=1;
							}

							// reseting the StringBuilder object so as to store the next word in it
							currentWord.setLength(0); 
						}
					}
					else{
						// appending the new character to the current word
						currentWord.append(line.charAt(i));
					}
				}				
			}
			
			// building the result Hashtable
			result.put("charCounter", charCounter);
			result.put("wordCounter", wordCounter);
			result.put("palindromeCounter", palindromeCounter);
			result.put("allPalindromes", allPalindromes);

			// closing the BufferedReader object
			br.close();
		}
		catch(Exception e){
			System.out.println("There was an exception. Exception message: "+e);
		}

		return result;
	}

	/**
	* This method checks if the given word is a palindrome
	*
	* @param	wordToTest - (StringBuilder) Stores the word to be checked
	*
	* @return	(boolean) true if it is a palindrome; false otherwise
	*
	*/
	boolean isPalindrome(StringBuilder wordToTest){
		// assumption: kayak and Kayak are both considered to be palindromes (that is, our checks are case insensitive)
		for(int i=0; i<wordToTest.length(); i++){
			if(Character.toLowerCase(wordToTest.charAt(i))!=Character.toLowerCase(wordToTest.charAt(wordToTest.length()-i-1))){
				return false;
			}
		}

		return true;
	}


}