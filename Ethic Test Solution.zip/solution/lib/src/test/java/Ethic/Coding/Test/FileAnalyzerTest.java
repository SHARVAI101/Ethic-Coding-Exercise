/**
 * This file contains unit tests for the methods defined in class FileAnalyzer
 * 
 * @author      Sharvai Patil (sp4479@g.rit.edu)
 * 
 */

package Ethic.Coding.Test;

import org.junit.Test;
import org.junit.Before;
import java.net.URLDecoder;
import static org.junit.Assert.assertEquals;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Arrays;
import java.util.Hashtable;

public class FileAnalyzerTest {

	private FileAnalyzer fileAnalyzerObject;

	private String testfile1;
	private String testfile2;

	private List<String> testFile1Palindromes;
	private List<String> testFile2Palindromes;

	@Before
	public void init() throws UnsupportedEncodingException {
		// Initializing the paths of the test files in the resources folder
		testfile1 = URLDecoder.decode(ClassLoader.getSystemClassLoader().getResource("testing.txt").getFile().toString(), "UTF-8");
		testfile2 = URLDecoder.decode(ClassLoader.getSystemClassLoader().getResource("testing2.txt").getFile().toString(), "UTF-8");
		
		// Initializing testFile1Palindromes by adding all the palindromes that occur in testfile1
		testFile1Palindromes = Arrays.asList("non", "non", "non", "deed", "121", "mom", "racecar", "non", "a", "non");

		// Initializing testFile2Palindromes by adding all the palindromes that occur in testfile2
		testFile2Palindromes = Arrays.asList("did", "did");

		// creating the FileAnalyzer object that we will use to test
		fileAnalyzerObject = new FileAnalyzer();
	}

	@Test
	public void testCheckFileExists() {       
		// testing if checkFileExists() returns false for a non-existent file
		assertEquals(false, fileAnalyzerObject.checkFileExists("test.txt"));

		// testing if checkFileExists() returns false for a file which isn't a text file
		assertEquals(false, fileAnalyzerObject.checkFileExists("test.png"));

		// testing if checkFileExists() returns true for a file which exists and is a text file
		assertEquals(true, fileAnalyzerObject.checkFileExists(testfile1));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testAnalyzeFile() {
		// testing analzeFile() using testfile1
		Hashtable<String, Object> result1 = fileAnalyzerObject.analyzeFile(testfile1);

		// testing if analyzeFile() returns the correct number of characters for testfile1
		assertEquals(3324, (int)result1.get("charCounter"));

		// testing if analyzeFile() returns the correct number of words for testfile1
		assertEquals(487, (int)result1.get("wordCounter"));

		// testing if analyzeFile() returns the correct number of palindromes for testfile1
		assertEquals(10, (int)result1.get("palindromeCounter"));
		
		// testing if analyzeFile() returns the all the correct palindromes
		List<Object> allPalindromes1 = (List)result1.get("allPalindromes");
		assertAllPalindromesEquivalence(testFile1Palindromes, allPalindromes1);

		// testing analzeFile() using testfile2
		Hashtable<String, Object> result2 = fileAnalyzerObject.analyzeFile(testfile2);

		// testing if analyzeFile() returns the correct number of characters for testfile2
		assertEquals(3884, (int)result2.get("charCounter"));

		// testing if analyzeFile() returns the correct number of words for testfile2
		assertEquals(605, (int)result2.get("wordCounter"));

		// testing if analyzeFile() returns the correct number of palindromes for testfile2
		assertEquals(2, (int)result2.get("palindromeCounter"));
		
		// testing if analyzeFile() returns the all the correct palindromes for testfile2
		List<Object> allPalindromes2 = (List)result2.get("allPalindromes");
		assertAllPalindromesEquivalence(testFile2Palindromes, allPalindromes2);
	}

	private static void assertAllPalindromesEquivalence(List<String> expected, List<Object> actual) {
		for(int i=0; i<actual.size(); i++){
			assertEquals(expected.get(i), actual.get(i).toString());
		}
	}

	@Test
	public void testIsPalindrome() {
		// testing if isPalindrome() returns true for a palindromic string
		assertEquals(true, fileAnalyzerObject.isPalindrome(new StringBuilder("abcaacba")));

		// testing if isPalindrome() returns false for a string that is not a palindrome
		assertEquals(false, fileAnalyzerObject.isPalindrome(new StringBuilder("hello")));
	}
}
